<div class="row">
	<div class="col-md-12">
	    <div class="portlet box blue-hoki">
        	<div class="portlet-title">
            <div class="caption">
                <i class="fa fa-gift"></i><?php echo $name;?>
            </div>
        </div>
        
<div class="portlet-body form">
    <!-- BEGIN FORM-->
    <?php echo validation_errors();?>
	 <?=form_open(NULL, array('class' => 'form-horizontal', 'role'=>'form','enctype'=>"multipart/form-data"))?>                
     <div class="form-body">                    
        <div class="col-md-12">
            <?php /*?><div class="form-group">
                  <label class="col-lg-2 control-label">Store</label>
                  <div class="col-lg-10">
                    <select name="store_id" class="form-control" required>
                    <option value="">Select</option>
    
<?php
if(isset($stores)&&!empty($stores)){
	foreach($stores as $setstores){
?>
	<option value="<?php echo $setstores->id; ?>" <?=$products->store_id==$setstores->id?'selected="selected"':'';?> ><?php echo $setstores->name; ?></option>
<?php
	}
}
?>
                        </select>
                  </div>
                </div><?php */?>
            <div class="form-group">
                  <label class="col-lg-2 control-label"><?=lang('').'Category'?></label>
                  <div class="col-lg-10">
                    <select name="category_id" class="form-control" required>
                    <option value="">Select</option>
    
<?php
if(isset($categories)&&!empty($categories)){
	foreach($categories as $setcategories){
?>
	<option value="<?php echo $setcategories->id; ?>" <?=$products->category_id==$setcategories->id?'selected="selected"':'';?> ><?php echo $setcategories->title; ?></option>
<?php
		$checkEntityName = $this->comman_model->get_lang('categories',$content_language_id,NULL,array('parent_id'=>$setcategories->id),'category_id',false);
		if($checkEntityName){
			foreach($checkEntityName as $set_checkEntityName){			
?>
		<option value="<?php echo $set_checkEntityName->id; ?>" <?=$products->category_id==$set_checkEntityName->id?'selected="selected"':'';?> style="padding-left:20px;color:#C30" ><?php echo $set_checkEntityName->title; ?></option>
<?php
			}	
		}
	}
}
?>
                        </select>
                  </div>
                </div>
			
                            
            <div class="form-group" >
      <label class="col-lg-2 control-label"><?=lang('')?>Price</label>
      <div class="col-lg-10">
        <?=form_input('price', set_value('price', $products->{'price'}), 'class="form-control " id="" placeholder="Price"')?>
      </div>
    </div>
			<div class="form-group" >
                    <label class="col-lg-2 control-label"><?=lang('')?>Product-Url</label>
                    <div class="col-lg-10">
                       <?=form_input('slug', set_value('slug', $products->{'slug'}), 'class="form-control " id="" placeholder="Product-Url"')?>
                    </div>
             </div>
            <div class="form-group">
              <label class="col-lg-2 control-label"><?=lang('image')?></label>
              <div class="col-lg-10">
                <div class="fileinput fileinput-new" data-provides="fileinput">
                    <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                        <?php echo !isset($products->image) ? '<img src="assets/uploads/no-image.gif">' :'<img src="'.base_url('assets/uploads/products/thumbnails').'/'.$products->image.'" >'; ?>
                    </div>
                    <div>
                    <span class="btn btn-default btn-file"><span class="fileinput-new">Select image</span><span class="fileinput-exists">Change</span>
                    <input type="file" name="logo" id="logo"></span>
                    <a href="#" class="btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                </div>
                </div>
                    <!--<input type="file" name="logo" id="logo" />-->
              </div>
            </div>

            
            
            <div class="form-group">
              <label class="col-lg-2 control-label">Feature</label>
              <div class="col-lg-10" style="padding-top:10px">
                <?=form_checkbox('is_feature', '1', set_value('is_feature', $products->is_feature), 'id="inputDefault" class="form-control "')?>
              </div>
	        </div>
                    
		</div>
        
    
       <div style="clear:both"></div>

      	<h5><?=lang('Translation data')?></h5>
     	<div style="margin-bottom: 0px;" class="tabbable">
              <ul class="nav nav-tabs">
                <?php $i=0;
              //   debugger($this->page_m->languages_icon);
              //  foreach($this->page_m->languages as $key_lang=>$val_lang):
                foreach($this->product_model->languages_icon as $key_lang=>$val_lang):

                  $i++;?>
                <li class="<?=$i==1?'active':''?>">
                  <a data-toggle="tab" href="#<?=$key_lang?>"><img src="<?php echo base_url('assets/uploads/language').'/'.$val_lang; ?>" height="15" width="20" ></a></li>
                <?php endforeach;?>
              </ul>
              <div style="padding-top: 9px; border-bottom: 1px solid #ddd;" class="tab-content">
                <?php $i=0;foreach($this->product_model->languages as $key_lang=>$val_lang):$i++;?>
                <div id="<?=$key_lang?>" class="tab-pane <?=$i==1?'active':''?>">
                    <div class="form-group">
                      <label class="col-lg-2 control-label"><?=lang('')?>Name</label>
                      <div class="col-lg-10">
                        <?=form_input('title_'.$key_lang, set_value('title_'.$key_lang, $products->{'title_'.$key_lang}), 'class="form-control copy_to_next" id="inputTitle'.$key_lang.'" placeholder="Name"')?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-lg-2 control-label">Body</label>
                      <div class="col-lg-10">
                        <?=form_textarea('body_'.$key_lang, html_entity_decode(set_value('body_'.$key_lang, $products->{'body_'.$key_lang})), 'placeholder="Body" rows="3" class="cleditor2 form-control"')?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-lg-2 control-label">Short Description</label>
                      <div class="col-lg-10">
                        <?=form_textarea('short_description_'.$key_lang, html_entity_decode(set_value('short_description_'.$key_lang, $products->{'short_description_'.$key_lang})), 'placeholder="meta description" rows="3" class="form-control"')?>
                      </div>
                    </div>

                </div>
                <?php endforeach;?>
              </div>
            </div>
	</div>
     <div class="form-actions">
            <div class="row">
                <div class="col-md-offset-2 col-md-9">
                    <?=form_submit('submit', lang('Save'), 'class="btn btn-primary"')?>
                    <a href="<?=site_url('admin/product/')?>" class="btn btn-default" type="button"><?=lang('Cancel')?></a>
                    <!--<button type="button" class="btn default">Cancl</button>-->
                </div>
            </div>
        </div>
         <?=form_close()?>
         
</div>
	    </div>
    </div>
	<div class="col-md-12">
	    <div class="portlet box blue-hoki">
        <div class="portlet-title">
            <div class="caption">
                <i class="fa fa-gift"></i><?php echo 'Photo';?>
            </div>
            <!--<div class="tools">
                <a href="javascript:;" class="collapse">
                </a>
                <a href="#portlet-config" data-toggle="modal" class="config">
                </a>
                <a href="javascript:;" class="reload">
                </a>
                <a href="javascript:;" class="remove">
                </a>
            </div>-->
        </div>
        <div class="portlet-body form">
    		<div class="col-md-12" style="">

              <div class="widget wlightblue">

                <div class="widget-head">
                  <div class="pull-left"><?=lang('Files')?></div>
                  <div class="widget-icons pull-right">
                    <a class="wminimize" href="#"><i class="icon-chevron-up"></i></a> 
                  </div>
                  <div class="clearfix"></div>
                </div>

                <div class="widget-content">
                  <div class="padd">

<?php if(!isset($products->id)):?>
<span class="label label-danger"><?=lang('After saving, you can add files and images');?></span>
<?php else:?>
<div id="page-files-<?=$products->id?>" rel="page_m">
    <!-- The file upload form used as target for the file upload widget -->
    <form class="fileupload" action="<?=site_url('admin/product/upload/'.$products->id);?>" method="POST" enctype="multipart/form-data">
        <!-- Redirect browsers with JavaScript disabled to the origin page -->
        <noscript><input type="hidden" name="redirect" value="<?=site_url('admin/product/edit/'.$products->id);?>"></noscript>
        <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
        <div class="fileupload-buttonbar">
            <div class="span7 col-md-7">
                <!-- The fileinput-button span is used to style the file input field as button -->
                <span class="btn btn-success fileinput-button">
                    <i class="icon-plus icon-white"></i>
                    <span>add_files</span>
                    <input type="file" name="files[]" multiple>
                </span>
                <button type="reset" class="btn btn-warning cancel">
                    <i class="icon-ban-circle icon-white"></i>
                    <span>Cancel</span>
                </button>
                <button type="button" class="btn btn-danger delete">
                    <i class="icon-trash icon-white"></i>
                    <span>Delete Selected</span>
                </button>
                <input type="checkbox" class="toggle" />
            </div>
            <!-- The global progress information -->
            <div class="span5 col-md-5 fileupload-progress fade">
                <!-- The global progress bar -->
                <div class="progress progress-success progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                    <div class="bar" style="width:0%;"></div>
                </div>
                <!-- The extended global progress information -->
                <div class="progress-extended">&nbsp;</div>
            </div>
        </div>
        <!-- The loading indicator is shown during file processing -->
        <div class="fileupload-loading"></div>
        <br />
        <!-- The table listing the files available for upload/download -->
        <!--<table role="presentation" class="table table-striped">
        <tbody class="files" data-toggle="modal-gallery" data-target="#modal-gallery">-->

          <div role="presentation" class="fieldset-content">
            <ul class="files files-list" data-toggle="modal-gallery" data-target="#modal-gallery">      
<?php if(isset($files[$products->id]))foreach($files[$products->id] as $file ):?>
            <li class="img-rounded template-download fade in">
                <div class="preview">
                    <img class="img-rounded" alt="<?=$file->filename?>" data-src="<?=$file->thumbnail_url?>" src="<?=$file->thumbnail_url?>">
                </div>
                <div class="filename">
                    <code><?=character_hard_limiter($file->filename, 20)?></code>
                </div>
                <div class="options-container">
                    <?php if($file->zoom_enabled):?>
                    <a data-gallery="gallery" href="<?=$file->download_url?>" title="<?=$file->filename?>" download="<?=$file->filename?>" class="zoom-button btn btn-xs btn-success"><i class="icon-search icon-white"></i></a>                  
                    <?php else:?>
                    <a target="_blank" href="<?=$file->download_url?>" title="<?=$file->filename?>" download="<?=$file->filename?>" class="btn btn-xs btn-success"><i class="icon-search icon-white"></i></a>
                    <?php endif;?>
                    <a data-toggle="modal" href="#myModal<?=$file->id?>" 
                          title="<?=$file->filename?>" 
                          download="<?=$file->filename?>" 
                          class="btn btn-xs btn-info">
                        <i class="icon-pencil icon-white"></i>
                    </a>  

                    <span class="delete">
                        <button class="btn btn-xs btn-danger" data-type="DELETE" data-url="<?=$file->delete_url?>"><i class="icon-trash icon-white"></i></button>
                        <input type="checkbox" value="1" name="delete">
                    </span>
                </div>
                    <?php /*?><div id="myModal<?=$file->id?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                  <h4 class="modal-title"><?=$file->filename?></h4>
                                </div>
                                <div class="modal-body">
                                  <div class="form-group">
                                    <label class="col-lg-2 control-label">Youtube Link</label>
                                    <div class="col-lg-10">
                                      <?=form_input('link_'.$file->id, set_value('link', $file->link), 'class="form-control" id="link_'.$file->id.'"')?>
                                    </div>
                                  </div>
                                  </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button>
                                  <button type="button" class="btn btn-primary" onclick="saveLink(<?=$file->id; ?>); ">Save changes</button>
                                </div>
                              </div>
                    </div>
                    </div><?php */?>
            </li>
<?php endforeach;?>
            </ul>
            <br style="clear:both;"/>
          </div>
    </form>

</div>
<?php endif;?>

                  </div>
                </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
              </div>  
              
            </div>
        </div>
    </div>
    </div>
</div>
<?php 
if(isset($products->id)){
	if(isset($files[$products->id])){
		foreach($files[$products->id] as $file ){
	?>
	<div id="myModal<?=$file->id?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                  <h4 class="modal-title"><?=$file->filename?></h4>
                                </div>
                                <div class="modal-body">
                                  <div class="form-group">
                                    <label class="col-lg-2 control-label">Youtube Link</label>
                                    <div class="col-lg-10">
                                      <?=form_input('link_'.$file->id, set_value('link', $file->link), 'class="form-control" id="link_'.$file->id.'"')?>
                                    </div>
                                  </div>
                                  <div style="clear:both"></div>
                                  </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button>
                                  <button type="button" class="btn btn-primary" onclick="saveLink(<?=$file->id; ?>); ">Save changes</button>
                                </div>
                              </div>
                    </div>
                    </div>
	<?php /*?><div id="myModal<?=$file->id?>" class="modal fade" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
				<h4 class="modal-title">Responsive & Scrollable</h4>
			</div>
			<div class="modal-body">
				<div class="scroller" style="height:300px" data-always-visible="1" data-rail-visible1="1">
					<div class="row">
						<div class="col-md-6">
							<h4>Some Input</h4>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
						</div>
						<div class="col-md-6">
							<h4>Some More Input</h4>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
							<p>
								<input type="text" class="col-md-12 form-control">
							</p>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" data-dismiss="modal" class="btn default">Close</button>
				<button type="button" class="btn green">Save changes</button>
			</div>
		</div>
	</div>
	</div><?php */?>
<?php
		}
	}
}
?>

<link href="assets/plugins/select2/select2.css" rel="stylesheet"/>
<script type="text/javascript" src="assets/plugins/select2/select2.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$('#select_tag').select2({placeholder: "Select Tags"});
});

</script>

<link href="assets/plugins/jasny-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="assets/plugins/jasny-bootstrap/js/jasny-bootstrap.min.js" type="text/javascript" language="javascript"></script> 
<script src="assets/plugins/ckeditor/ckeditor.js" type="text/javascript" language="javascript"></script> 
<script src="assets/plugins/ckeditor/adapters/jquery.js" type="text/javascript" language="javascript"></script> 
<script>
/* CL Editor */
$(document).ready(function(){
    $('.cleditor2').ckeditor();
});
</script>





    
<link href="assets/plugins/multiuploader/css/custom.css" rel="stylesheet">

<link rel="stylesheet" href="assets/plugins/multiuploader/css/blueimp-gallery.min.css">
<link rel="stylesheet" href="assets/plugins/multiuploader/css/jquery.fileupload-ui.css">
<noscript><link rel="stylesheet" href="assets/plugins/multiuploader/css/jquery.fileupload-ui-noscript.css"></noscript>    
<script src="assets/plugins/multiuploader/js/bootstrap-image-gallery.js"></script>
<script src="assets/plugins/multiuploader/js/blueimp-gallery.min.js"></script>
<script src="assets/plugins/multiuploader/js/jquery.iframe-transport.js"></script>
<script src="assets/plugins/multiuploader/js/jquery.fileupload.js"></script>
<script src="assets/plugins/multiuploader/js/jquery.fileupload-fp.js"></script>
<script src="assets/plugins/multiuploader/js/jquery.fileupload-ui.js"></script>
<script type="text/javascript">
    $(function () {
        
        $('.zoom-button').click(function()
        {
            var myLinks = new Array();
            var current = $(this).attr('href');
            var curIndex = 0;
            
            $('.files-list .zoom-button').each(function (i) {
                var img_href = $(this).attr('href');
                myLinks[i] = img_href;
                if(current == img_href)
                    curIndex = i;
            });

            options = {index: curIndex}

            blueimp.Gallery(myLinks, options);
            
            return false;
        });
        
        loadjQueryUpload();
    });



    function show_animation()
    {
        $('#saving_container').css('display', 'block');
        $('#saving').css('opacity', '.8');
    }

    function hide_animation()
    {
        $('#saving_container').fadeOut();
    }


    
    $.fn.startLoading = function(data){
        //$('#saveAll, #add-new-page, ol.sortable button, #saveRevision').button('loading');
    }
    
    $.fn.endLoading = function(data){
        //$('#saveAll, #add-new-page, ol.sortable button, #saveRevision').button('reset');       
        <?php if(config_item('app_type') == 'demo'):?>
            ShowStatus.show('<?=lang('Data editing disabled in demo')?>');
        <?php else:?>
            //ShowStatus.show('<?=lang('data_saved')?>');
        <?php endif;?>
    }
    
    function loadjQueryUpload()
    {
        $('form.fileupload').each(function () {
            $(this).fileupload({
            <?php if(config_item('app_type') != 'demo'):?>
            autoUpload: true,
            <?php endif;?>
            // The maximum width of the preview images:
            previewMaxWidth: 160,
            // The maximum height of the preview images:
            previewMaxHeight: 120,
            uploadTemplateId: null,
            downloadTemplateId: null,
            uploadTemplate: function (o) {
                var rows = $();
                $.each(o.files, function (index, file) {
                    var row = $('<li class="img-rounded template-upload">' +
                        '<div class="preview"><span class="fade"></span></div>' +
                        '<div class="filename"><code>'+file.name+'</code></div>'+
                        '<div class="options-container">' +
                        '<span class="cancel"><button  class="btn btn-xs btn-warning"><i class="icon-ban-circle icon-white"></i></button></span></div>' +
                        (file.error ? '<div class="error"></div>' :
                                '<div class="progress">' +
                                    '<div class="bar" style="width:0%;"></div></div></div>'
                        )+'</li>');
                    row.find('.name').text(file.name);
                    row.find('.size').text(o.formatFileSize(file.size));
                    if (file.error) {
                        row.find('.error').text(
                            locale.fileupload.errors[file.error] || file.error
                        );
                    }
                    rows = rows.add(row);
                });
                return rows;
            },
            downloadTemplate: function (o) {
                var rows = $();
                $.each(o.files, function (index, file) {
                    var row = $('<li class="img-rounded template-download fade">' +
                        '<div class="preview"><span class="fade"></span></div>' +
                        '<div class="filename"><code>'+file.short_name+'</code></div>'+
                        '<div class="options-container">' +
                        (file.zoom_enabled?
                            '<a data-gallery="gallery" class="zoom-button btn btn-xs btn-success" download="'+file.name+'"><i class="icon-search icon-white"></i></a>'
                            : '<a target="_blank" class="btn btn-xs btn-success" download="'+file.name+'"><i class="icon-search icon-white"></i></a>') +
                        ' <span class="delete"><button class="btn btn-xs btn-danger" data-type="'+file.delete_type+'" data-url="'+file.delete_url+'"><i class="icon-trash icon-white"></i></button>' +
                        ' <input type="checkbox" value="1" name="delete"></span>' +
                        '</div>' +
                        (file.error ? '<div class="error"></div>' : '')+'</li>');
    
                    if (file.error) {
                        row.find('.name').text(file.name);
                        row.find('.error').text(
                            file.error
                        );
                    } else {
                        row.find('.name a').text(file.name);
                        if (file.thumbnail_url) {
                            row.find('.preview').html('<img class="img-rounded" alt="'+file.name+'" data-src="'+file.thumbnail_url+'" src="'+file.thumbnail_url+'">');  
                        }
                        row.find('a').prop('href', file.url);
                        row.find('a').prop('title', file.name);
                        row.find('.delete button')
                            .attr('data-type', file.delete_type)
                            .attr('data-url', file.delete_url);
                    }
                    rows = rows.add(row);
                });
                
				//window.load();
                return rows;
            },
            destroyed: function (e, data) {
                $.fn.endLoading();
                return false;
            },
            finished: function (e, data) {
                $('.zoom-button').unbind('click');
                $('.zoom-button').click(function()
                {
                    var myLinks = new Array();
                    var current = $(this).attr('href');
                    var curIndex = 0;
                    
                    $('.files-list .zoom-button').each(function (i) {
                        var img_href = $(this).attr('href');
                        myLinks[i] = img_href;
                        if(current == img_href)
                            curIndex = i;
                    });
            
                    options = {index: curIndex}
            
                    blueimp.Gallery(myLinks, options);
                    
                    return false;
                });
            },
            dropZone: $(this)
        });
        });       
        
        $("ul.files").each(function (i) {
            $(this).sortable({
                update: saveFilesOrder
            });
            $(this).disableSelection();
        });
    
    }
    
    function filesOrderToArray(container)
    {
        var data = {};

        container.find('li').each(function (i) {
            var filename = $(this).find('.options-container a:first').attr('download');
            data[i+1] = filename;
        });
        
        return data;
    }
    
    function saveFilesOrder( event, ui )
    {
        var filesOrder = filesOrderToArray($(this));
        var pageId = $(this).parent().parent().parent().attr('id').substring(11);
        var modelName = $(this).parent().parent().parent().attr('rel');
        
        $.fn.startLoading();
		$.post('<?=site_url('admin/product/file_order'); ?>/'+pageId, 
        { 'page_id': pageId, 'order': filesOrder }, 
        function(data){
            $.fn.endLoading();
		}, "json");
    }

    
    function saveLink(id){
       // $.fn.startLoading();
        $.post('<?=site_url('admin/product/update_link'); ?>', { id: id,links:$('#link_'+id).val(),slide_lang:$('#slide_lang_'+id).val() }, function(data){
            if(data.status){
                $('.label').remove();
                $('#link_'+id).after('<label class="label label-success" >'+data.message+'</label>');
            }else{
                $('.label').remove();
                 $('#link_'+id).after('<label class="label label-success" >'+data.message+'</label>');
            }
            $.fn.endLoading();
        }, "json");
    }  

</script>

