<div class="row">
	<div class="col-md-12">
	    <div class="portlet box blue-hoki">
        <div class="portlet-title">
            <div class="caption">
                <i class="fa fa-gift"></i><?php echo $name;?>
            </div>
            <!--<div class="tools">
                <a href="javascript:;" class="collapse">
                </a>
                <a href="#portlet-config" data-toggle="modal" class="config">
                </a>
                <a href="javascript:;" class="reload">
                </a>
                <a href="javascript:;" class="remove">
                </a>
            </div>-->
        </div>
        <div class="portlet-body form">
            <!-- BEGIN FORM-->
            <?php echo validation_errors();?>
			<?=form_open(NULL, array('class' => 'form-horizontal', 'role'=>'form','enctype'=>"multipart/form-data"))?>                              
            	<input type="hidden" name="operation" value="set" />
                <div class="form-body">                    
                    <div class="form-group">
                      <label class="col-lg-2 control-label">Home background</label>
                      <div class="col-lg-10">
                        <?=form_dropdown('type', $types, $this->input->post('type') ? $this->input->post('type') : $page->type, 'class="form-control"')?>
                      </div>
                    </div>
                   
                </div>
                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-offset-2 col-md-9">
                            <?=form_submit('submit', 'Save', 'class="btn btn-primary"')?>
                    <!--<button type="button" class="btn default">Cancl</button>-->
                        </div>
                    </div>
                </div>
            <?=form_close()?>
            <!-- END FORM-->
        </div>
    </div>
    </div>
    
</div>

