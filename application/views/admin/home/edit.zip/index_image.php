<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet box grey-cascade">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-globe"></i><?php echo $name;?>
                </div>
                <!--<div class="tools">
                    <a href="javascript:;" class="collapse">
                    </a>
                    <a href="#portlet-config" data-toggle="modal" class="config">
                    </a>
                    <a href="javascript:;" class="reload">
                    </a>
                    <a href="javascript:;" class="remove">
                    </a>
                </div>-->
            </div>
            <div class="portlet-body">
                <div class="table-toolbar">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="btn-group">
                                <a href="admin/home/edit_image"class="btn green">
                                Add New <i class="fa fa-plus"></i>
                                </a>

                            </div>
                        </div>
                    </div>
                </div>
                <table class="table table-striped table-bordered table-hover" id="sample_6">
                <thead>
                <tr>
                    <th>ID</th>								
                    <th>Name</th>
                    <th>Day Image</th>
                    <th>Night Image</th>
                    <th>Default</th>
                    <th>Options</th>
                </tr>
                </thead>
                <tbody>

<?php
if(count($all_data)){
	foreach($all_data as $set_data){
		if(isset($set_data->image)){
			$image = base_url('assets/uploads/home').'/'.$set_data->image; 
		}
		else{
			$image = "assets/uploads/no-image.gif";
		}
		if(isset($set_data->image1)){
			$image1 = base_url('assets/uploads/home').'/'.$set_data->image1; 
		}
		else{
			$image1 = "assets/uploads/no-image.gif";
		}

?>
                        <tr>
							<td><?php echo $set_data->id; ?></td>
							<td><?php echo $set_data->name; ?></td>
							<td><img src="<?=$image?>" class="img-rounded" style="width:30px;height:30px"> </td>
							<td><img src="<?=$image1?>" class="img-rounded" style="width:30px;height:30px"> </td>							
                            <td><?=($set_data->is_active == 1)?'<i class="fa fa-check"></i>':''?></td>					
							<td>
                            	<a href="admin/home/edit_image/<?php echo $set_data->id;?>"  >Edit</a>
                            	<a href="admin/home/delete/image/<?php echo $set_data->id;?>"  onclick="return confirm_box();"><?php echo $this->lang->line('delete');?></a>

                            </td>							
                        </tr>

<?php             
   }
}
?>                        

                </tbody>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>

<script>
function get_active(name,id,value){
    $.ajax({
       type: "POST",
       url: "admin/product/get_active", /* The country id will be sent to this file */
       data: {id:id,type:name,value:value},
       beforeSend: function () {
	      $("#show_class").html("Loading ...");
        },
       success: function(msg){
		 //alert(msg);
		//location.reload();
    	$("#show_class").html(msg);
       }
       });
}
function get_status(name,id,value){
	//alert(name+' '+id+' '+value);
    $.ajax({
       type: "POST",
       url: "admin/product/get_confirm", /* The country id will be sent to this file */
       data: "id="+id+"&confirm="+value,
       beforeSend: function () {
	      $("#show_class").html("Loading ...");
        },
       success: function(msg){
		 //alert(msg);
		//location.reload();
    	$("#show_class").html(msg);
       }
       });
} 

function confirm_box(){
    var answer = confirm ("Are you sure?");
    if (!answer)
     return false;
}
</script>