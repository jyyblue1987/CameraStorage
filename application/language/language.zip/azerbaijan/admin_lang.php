<?php
//common terms
$lang['update_balance']				= 'equilíbrio atualização';
$lang['paid_to']					= 'pago para';
$lang['setting']					= 'cenário';
$lang['website_setting']			= 'cenário de manutenção do site';
$lang['my_backup']					= 'meu backup';
$lang['message']					= 'mensagem';
$lang['admin_message']				= 'mensagem de administração';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['code']					= 'código';

$lang['update']					= 'atualizar';

$lang['select']					= 'selecionar';

$lang['english']				= 'Inglês';

$lang['portuguese']				= 'português';

$lang['hello'] 					= 'Olá';	

$lang['admin_login'] 			= 'Admin Login';

$lang['login']					= 'Login';

$lang['change_password'] 		= 'alterar a senha';

$lang['logout']					= 'Sair';

$lang['dashboard'] 				= 'painel de instrumentos';

$lang['username'] 				= 'Nome de Usuário';
$lang['send']					= 'enviar';

$lang['password'] 				= 'senha';

$lang['back_to_site']			= 'Voltar para o site';

$lang['delete'] 				= 'excluir';
$lang['pay_invoice'] 			= 'pagar fatura';
$lang['exclusive_advanced']		= 'exclusivo avançado';
$lang['exclusive']				= 'exclusivo';

$lang['active'] 				= 'ativo';

$lang['bonus_point']			= 'ponto de bônus';
$lang['new_entries']			= 'novas entradas';

$lang['propaganda'] 			= 'Propaganda';

$lang['level']					= 'nível';

$lang['rank']					= 'categoria';

$lang['total']		 			= 'Total';

$lang['direct']					= 'direto';

$lang['inactive'] 				= 'inativo';

$lang['status'] 				= 'estado';

$lang['option'] 				= 'opção';

$lang['add'] 					= 'adicionar';

$lang['description']			= 'descrição';

$lang['image']					= 'imagem';

$lang['date']					= 'data';

$lang['edit']					= 'editar';

$lang['sort_desc']				= 'descrição tipo';

$lang['footer']					= 'rodapé';

$lang['invoice_num']			= 'número da nota fiscal';
$lang['link']					= 'link';

$lang['ebook_list']				= 'lista ebook';

$lang['legal_document_list']	= 'Legal Lista de Documentos';

$lang['video_list']				= 'lista de vídeo';

$lang['file']					= 'arquivo';

$lang['gender']					= 'desconhecido';

$lang['payment_trans_his']		= 'história transecção pagamento';

$lang['not_confirm']			= 'não confirmar';

$lang['get_confirm']			= 'obter confirmação';

$lang['tax_percent']			= 'por cento de imposto';
$lang['from']					= 'a partir de';
$lang['to']						= 'para';
$lang['report']					= 'relatório';
$lang['terms_use']				= 'termos de uso';
$lang['contract_company']		= 'companhia contrato';
$lang['privacy_policy']			= 'política de privacidade';

$lang['from_bonus_point']		= 'do ponto de bônus';
$lang['from_balance']			= 'de equilíbrio';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';

$lang['']= '';





//withdraw

$lang['your_balance']			= 'o seu equilíbrio';
$lang['balance']				= 'equilíbrio';
$lang['qualification']			= 'qualificação';

$lang['tax']					= 'impuesto';

$lang['pending']				= 'pendente';

$lang['total_amount']			= 'montante total';

$lang['percent_ammount']		= 'percentagem da quantidade';


$lang['']			= '';

$lang['']			= '';

$lang['']			= '';





//ticket

$lang['subject']			= 'assunto';

$lang['message']			= 'mensagem';

$lang['reply']				= 'responder';

$lang['comments']			= 'Comentários';

$lang['comment']			= 'comentário';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';



//menu

$lang['ticket'] 				= 'bilhete';

$lang['withdrawal']				= 'Retirada requisição por usuário';

$lang['help'] 					= 'ajudar';

$lang['tax']					= 'impuesto sobre la retirada';



//tax

$lang['percent']			= 'por ciento';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';



//marketing

$lang['level']			= 'nivel';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';

$lang['']			= '';



//help

$lang['technical_support'] 		= 'Suporte Técnico';

$lang['manual'] 				= 'manual ';	

$lang['how_it_work'] 			= 'Como Funciona?';			





//paypal_detail

$lang['rate']					= 'taxa';

$lang['product_name']			= 'nome do produto';

$lang['amount']					= 'quantidade';

$lang['price']					= 'preço';

$lang['user_code']				= 'código do usuário';

$lang['']				= '';

$lang['']				= '';



//view user

$lang['business']				= 'negócio';

$lang['cnpj']					= 'CNPJ';

$lang['country']				= 'país';

$lang['state']					= 'estado';

$lang['city']					= 'cidade';

$lang['address']				= 'endereço';

$lang['reference']				= 'referência';

$lang['neighborhood']			= 'bairro';

$lang['zip_code']				= 'CEP';

$lang['phone']					= 'telefone';

$lang['operator']				= 'operador';





//menu

$lang['menu_list'] 				= 'Lista de menus';

$lang['top_indicator'] 			= 'Indicador Top';

$lang['user_list'] 				= 'Lista de usuários';

$lang['transection_history'] 	= 'História transecção';

$lang['config_marketing'] 		= 'Configuração de Marketing';

$lang['payment_method'] 		= 'Forma de Pagamento';

$lang['confirm_payment'] 		= 'A confirmação do pagamento';

$lang['confirm_bank_account'] 	= 'Confirmação de Conta Bancária';

$lang['content_change'] 		= 'Alterar conteúdo';

$lang['training_area'] 			= 'Área de Formação';

$lang['number_nominess'] 		= 'Número de Nominees';

$lang['delinquent'] 			= 'delinquente';

$lang['sending_sms'] 			= 'Envio de SMS';

$lang['list_commission'] 		= 'Lista Comissão';

$lang['distribute_commi']		= 'distribuir Comissão';

$lang['loot'] 					= 'saque';

$lang['bill_pending']			= 'contas pendentes';

$lang['area_customer']			= 'Área de Clientes';

$lang['partners'] 				= 'parceiros';

$lang['financial_dashboard'] 	= 'Painel Financeiro';

$lang['individuals'] 			= 'painel de instrumentos';

$lang['visit_site']				= 'visite o site';

$lang['manage_roles']			= 'Gerenciar funções';











$lang['company_name']			= 'nome da empresa';

$lang['logo']					= 'logotipo';

$lang['about']					= 'sobre';

$lang['contact_us']				= 'entre em contato conosco';

$lang['content_list']			= 'lista de conteúdos';

$lang['slider_list']			= 'lista deslizante';

$lang['footer_name']			= 'nome rodapé';

$lang['social_media']			= 'mídias sociais';

$lang['ebook']					= 'E-books';

$lang['video'] 					= 'Vídeos';

$lang['legal_document'] 		= 'Documento Legal';









//dashboard

$lang['welcome_admin']			= 'bem-vindo ao administrador';

//change password

$lang['old_password']			= 'senha antiga';

$lang['new_password']			= 'Nova senha';

$lang['confirm']				= 'confirmar';



//user list

$lang['type']					= 'tipo';

$lang['contact']				= 'contato';

$lang['mini_email']				= 'mini-mail';

$lang['name']					= 'nome';

$lang['email']					= 'e-mail';





//payment_method

$lang['payment_method_list']	= 'Lista método de pagamento';

$lang['payment_method_name']	= 'Nome do método de pagamento';

$lang['your_mail_id']			= 'seu ID de correio';

$lang['currency']				= 'moeda';

$lang['address']				= 'endereço';

$lang['your_id']				= 'seu id';

$lang['account_number']			= 'número de conta';

$lang['customer_id']			= 'ID de cliente';



$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

