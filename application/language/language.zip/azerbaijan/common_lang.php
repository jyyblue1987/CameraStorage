<?php
//common terms
$lang['Subscribe For Newsletter']			= 'Xəbərlərə üçün abunə';
$lang['Enter']								= 'girmək';



$lang['maintenance']				= 'manutenção';

//edit by you
$lang['user_maintenance_msge']				= '';
$lang['web_maintenance_msge']				= '';



$lang['back']					= 'de volta';
$lang['home']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';
$lang['']				= '';

$lang['home']					= "casa"; 

$lang['login']					= 'login';

$lang['logout']					= 'Sair';

$lang['operation']				= 'operação';

$lang['faq']			        = 'FAQ';

$lang['contact']				= 'contato';

$lang['contact_us']				= 'Fale Conosco';

$lang['register']				= 'registrar';

$lang['search']					= 'pesquisa';

$lang['featured_pages']			= 'Páginas em destaque';

$lang['information']			= 'informações';

$lang['recent_posts']			= 'Mensagens recentes';

$lang['featured']				= 'Destaque';

$lang['read_more']				= 'Leia mais';

$lang['about_us']				= 'sobre nós';

$lang['register_form']			= 'Registre-Form';
$lang['exclusive_advanced']		= 'exclusivo avançado';
$lang['terms_use']				= 'termos de uso';
$lang['contract_company']		= 'companhia contrato';
$lang['from_bonus_point']		= 'do ponto de bônus';
$lang['from_balance']			= 'de equilíbrio';
$lang['privacy_policy']			= 'política de privacidade';
$lang['exclusive']				= 'exclusivo';

$lang['email']					= 'E-mail';

$lang['email_required']			= 'O campo e-mail é necessário. ';

$lang['password']           	= 'senha ';

$lang['password_required']		= 'O campo senha é necessária. ';

$lang['confirm']				= 'confirmar ';

$lang['confirmation_required']	= 'O campo de confirmação de senha é necessária. ';

$lang['personal_data']			= 'DADOS PESSOAIS ';

$lang['type']					= 'Tipo';

$lang['individuals']			= 'Indivíduos';

$lang['legal_entities']			= 'Pessoa Jurídica (Empresa)';

$lang['name']					= 'Nome';

$lang['name_required.']			= 'O campo de nome é obrigatório. ';

$lang['sex']					= 'Sexo';

$lang['male']					= 'Masculino';

$lang['female']					= 'Feminino ';

$lang['birth']					= 'nascimento ';

$lang['cpf']					= 'CPF ';

$lang['rg']						= 'RG (identidade) ';

$lang['business']				= 'negócio ';

$lang['cnpj']					= 'CNPJ ';

$lang['country']				= 'país ';

$lang['state']					= 'estado ';

$lang['city']					= 'cidade ';

$lang['address']				= 'endereço ';

$lang['reference']				= 'referência ';

$lang['neighborhood']			= 'bairro ';

$lang['zip_code']				= 'CEP ';

$lang['phone']					= 'telefone ';

$lang['operator']				= 'operador ';

$lang['cellular']				= 'celular ';

$lang['data_receive']			= 'Dados para receber (Você pode informar DEPOIS) ';

$lang['pagseguro_mail']			= 'PagSeguro e-mail ';

$lang['paypal_mail']			= 'PayPal e-mail ';

$lang['moip_mail']				= 'MOIP e-mail ';

$lang['hipay_mail']				= 'HiPay e-mail ';

$lang['f2b_mail']				= 'F2B e-mail ';

$lang['bank']					= 'Banco ';

$lang['holder']					= 'titular ';

$lang['agency']					= 'agência ';

$lang['account']				= 'conta ';

$lang['account_type']			= 'Poupança Corrente ';

$lang['savings']				= 'Poupança';

$lang['current']				= 'Corrente ';

$lang['other_data']				= 'Outros Dados ';

$lang['your_mini_site']			= 'Seu Mini Site';

$lang['your_mini_email']		= 'Seu e-mail Mini Site ';

$lang['site_required.']			= 'O campo de referência do site é necessária. ';

$lang['spaces_required']		= '(Sem espaços, e caractere acentuado ou especial - pode informar depois) ';

$lang['site_email_required']	= 'O campo de e-mail do site é necessária. ';

$lang['contact_form']			= 'Formulário de Contato ';

$lang['website']				= 'site ';

$lang['comments']				= 'Comentários';

$lang['send']					= 'enviar';

$lang['business']				= 'negócio';

$lang['submit']					= 'submeter';

$lang['back']				= 'de volta';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

$lang['']				= '';

//$lang['about_us']				= 'Компания';



   







 









 











